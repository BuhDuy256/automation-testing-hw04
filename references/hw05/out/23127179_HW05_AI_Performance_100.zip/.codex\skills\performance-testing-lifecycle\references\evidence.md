# Execution Evidence

Prepare evidence before official traffic. Requirements discovered afterward cannot be repaired by pretending later artifacts came from that invocation.

## Designated report uniqueness

Before assigning a scenario report:

1. Read the authoritative assignment's listener/report requirement.
2. Read the task-specific registry of already-assigned designated report types.
3. Normalize names enough to detect the same mechanism under cosmetic labels.
4. Refuse reuse when distinct types are required.
5. Record selected type, scenario, status, and artifact path before execution.

Raw machine-readable logs, summary JSON, stdout/stderr, resource CSV, and screenshots are common evidence. They may recur, but do not replace a distinct designated listener/report. Do not assign future modes merely to fill the registry.

## Invocation package

Use a new collision-safe run ID and non-overwriting directory. Preserve:

- exact implementation and data, with hashes where useful;
- exact command and traffic-relevant environment;
- tool version, commit, run ID, and timestamps;
- direct raw results, machine summary, and threshold exit state;
- stdout/stderr and stable per-step metrics with counts;
- backend, generator, and practical whole-machine samples across phases;
- hardware context, designated report, and report-view evidence;
- interruption, failure, restart, reseed, collision, and evidence notes.

Never reconstruct raw results from a summary or overwrite an older valid invocation.

## GUI screenshot preflight

When same-run evidence is required, arrange it before traffic. Show the active tool and backend resource usage in the same frame, with enough context for attribution. Prefer run ID, phase, timestamp, and process IDs. Show generator usage separately when it shares the SUT machine.

Hardware evidence is separate from the tool/resource screenshot unless explicitly combined. Never represent an after-the-fact image as evidence from a completed invocation.

## Desktop handoff

If the coding agent cannot capture the GUI, create a concise handoff containing prerequisites, SUT state, exact command/run ID, visible process columns, required phase/destination, optional video preparation, post-run checks, and an anti-fabrication warning.

On Windows, Task Manager or Resource Monitor may run at a higher integrity level. If automation fails with access denied, stop claiming full automation. Ask the student to perform only the blocked view/sort/placement action, then capture real frames and record the UAC limitation as an evidence constraint, not a test defect.

For GUI evidence requiring visible desktop windows, do not assume a process launched from a ConPTY/tool shell will have a desktop HWND. Before traffic, verify the evidence pane is actually visible on the interactive desktop, not merely alive as a process.

## Validity versus completeness

Assess independently:

- **Technical validity:** the intended test ran under valid conditions and results are trustworthy.
- **Submission completeness:** every mandated raw, report, resource, screenshot, hardware, and video artifact exists and is attributable.

A run may be technically valid and submission-incomplete. Preserve it, then obtain human approval before any evidence-completion rerun.
