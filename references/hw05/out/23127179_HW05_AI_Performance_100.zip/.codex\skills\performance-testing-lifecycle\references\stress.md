# Stress Mode

Use Stress mode to progressively exceed the reviewed normal-load baseline and make degradation or instability regions observable. Do not search for an arbitrary largest virtual-user number.

## Required starting evidence

Read the approved Load design, raw Load results, correctness outcome, latency distribution, throughput, and backend/generator resources. If the Load baseline is missing or invalid, stop and establish it first unless the assignment explicitly defines another baseline.

## Scenario design

1. Preserve the reviewed business workflow and state-isolation strategy.
2. Choose progressive levels from baseline behavior and available hardware headroom.
3. Give each level enough time for repeated complete workflows and sustained change.
4. Make the transition from normal behavior to degradation, errors, saturation, or instability visible.
5. Define recovery or graceful completion when required.

Do not silently remove or shorten think-time to create pressure. Any change changes the traffic model and requires explicit human review.

## Observation and stopping

At each level observe semantic workflow success, transport errors, latency tails, throughput, backend resources, generator resources, and state growth. Distinguish threshold failure from invalid execution.

Define stopping criteria for backend crash, machine instability, generator saturation, lost evidence, or a condition making remaining traffic meaningless or unsafe. Retain ordinary degradation and failures as the purpose of the run. Never rerun automatically to replace an unfavorable result.

The maximum, stages, duration, and thresholds remain task-specific human-reviewed decisions supported by Load evidence; this reference supplies no default counts or durations.
