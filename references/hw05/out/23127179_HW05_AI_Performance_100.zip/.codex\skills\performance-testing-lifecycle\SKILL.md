---
name: performance-testing-lifecycle
description: Design, review, implement, execute, evidence, or analyze an end-to-end performance-test scenario using load, stress, spike, or soak/endurance mode. Use when work must move from authoritative requirements and runtime verification through data design, calibration, human review, test execution, attributable evidence, and result analysis without fabricating outputs or silently changing reviewed parameters.
---

# Performance Testing Lifecycle

Use an evidence-first, gated workflow. Keep scenario-specific plans separate from reusable rules.

## Resolve inputs

Identify these inputs before designing traffic:

- authoritative assignment or requirement;
- SUT/API contract and chosen end-to-end workflow;
- verified runtime workflow contract;
- controlled CSV/test-data source;
- `scenario_type`: `load`, `stress`, `spike`, or `soak`; treat `endurance` as an alias of `soak`;
- previous scenario results and calibration evidence, when available;
- hardware and generator-placement context;
- registry of already-assigned designated report types;
- output/evidence destination and naming convention.

Treat each source as authoritative only for what it contains. Stop and request a missing source when business behavior, evidence obligations, or a reviewed workload decision cannot be recovered safely.

## Label the basis of decisions

Use these labels in plans and reviews:

- **Assignment requirement**: mandated by the authoritative brief.
- **Observed runtime fact**: verified from the running SUT or implementation.
- **Calibration measurement**: measured in a controlled exploratory run.
- **AI proposal**: suggested but not yet accepted.
- **Synthetic assumption**: deliberately modeled without production evidence.
- **Human-reviewed decision**: explicitly accepted or corrected by the responsible human.

Never upgrade an AI proposal or synthetic assumption into a business requirement.

## Run the lifecycle

1. Read the assignment and current scenario state. Extract workflow, naming, reporting, screenshot, video, raw-output, hardware, and review requirements.
2. Inspect the SUT and API. Select or consume one workflow covering required endpoint groups. Preserve it across scenarios when required.
3. Verify the workflow against the running SUT. Record request shapes, semantic success criteria, persistent state, and runtime correlations.
4. Design data. Keep only controlled input in CSV; generate or extract tokens, identifiers, returned values, and prices at runtime. Isolate mutable state across concurrent iterations.
5. Read the reference matching `scenario_type`: [load.md](references/load.md), [stress.md](references/stress.md), [spike.md](references/spike.md), or [soak.md](references/soak.md). Route `endurance` to `soak.md`. Consume previous results where the mode requires them.
6. Produce a scenario design with parameter rationale, correctness checks, metrics, thresholds, stop conditions, and unresolved assumptions.
7. Pause for human review. Freeze the accepted workflow, data strategy, workload, think-time, thresholds, report type, and evidence plan before official execution.
8. Assign the designated report through [evidence.md](references/evidence.md) and record it in task-specific state.
9. Implement only the reviewed design. Tag stable steps, correlate dependent values, and end an iteration safely after a required correlation or semantic check fails.
10. Validate structure, data loading, state isolation, request count, correlations, think-time, thresholds, and absence of hard-coded runtime fallbacks.
11. Prepare evidence before traffic: an invocation-specific directory, command, run ID, tool version, monitoring, report output, and required GUI handoff.
12. Execute once under the reviewed configuration. Never silently change parameters. A threshold failure is evidence, not permission to rerun automatically.
13. Verify raw output, summary, step/workflow counts, failures, thresholds, resource coverage, report generation, and screenshot attribution. Keep older valid invocations unchanged.
14. Classify technical validity and submission completeness separately.
15. Analyze results only when requested, following [result-analysis.md](references/result-analysis.md).

## Correctness rules

- Do not treat an accepted HTTP status alone as workflow success.
- Check response meaning, required fields, identities, calculated values, and state-changing payloads.
- Do not issue dependent requests after a required token, identifier, selection, or value is missing.
- Track complete-workflow success separately from transport failures and individual checks.
- Do not hard-code dynamic correlation values as a fallback.

## Evidence rules

Always read [evidence.md](references/evidence.md) before implementation or execution. Preserve direct raw results, summaries, console output, per-step metrics, resources, command, version, timestamps, run identity, and failure notes. Never reconstruct raw results or fabricate GUI evidence.

When the coding agent cannot operate the desktop, create a minimal handoff for a desktop-capable assistant or human. If Windows integrity boundaries block automation of an elevated monitor, request only the necessary human action and record the limitation.

## Stop conditions

Stop before traffic when a required source or reviewed decision is missing, a designated report would violate uniqueness, evidence capture is not ready, the SUT/data state is invalid, or implementation differs materially from the reviewed plan.

During a run, stop only for invalid conditions such as unavailable SUT, corrupted evidence collection, setup-caused identity collision, backend crash preventing meaningful completion, or machine instability. Slowness, errors, and threshold failures are normally results to retain.
