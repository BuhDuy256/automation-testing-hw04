# Soak / Endurance Testing

Use a stable sustained load to investigate time-dependent correctness, latency, throughput,
resource behavior, and persistent-state effects. Do not turn Soak into progressive Stress or
a sudden Spike.

## Design the sustained observation

1. Select a sustained load from prior measurements, correctness evidence, generator and SUT
   headroom, shared-machine constraints, and expected persistent-state growth. Do not infer
   production demand from a synthetic level.
2. Exclude an explicit warm-up or entry interval from steady conclusions.
3. Divide the accepted steady duration into comparable early, middle, and late windows.
4. Anchor every window to the actual scenario start created by the load tool. Keep runner
   preflight time separate.
5. Record schedule-derived target concurrency and independently measured actual concurrency.
   Use a steady window only when actual-concurrency evidence supports it.
6. Preserve the reviewed workflow, data isolation, correlations, semantic checks, pacing,
   and persistent-state behavior unless a new authoritative requirement changes them.

Pause for human review before implementation. Freeze the load, duration, entry and exit,
steady windows, pacing, correctness thresholds, evidence outputs, sampling, screenshots,
recovery, and invalid-run rules.

## Measure over time

Use timestamped raw results as the detailed source. Attribute requests by response window,
record workflow start and end windows, count cross-window iterations, and keep same-window
iteration duration separate where useful.

For every steady window, preserve factual counts and rates for requests, completed workflows,
failures, checks, workflow success, latency percentiles, and actual concurrency. Keep custom
metrics small; derive detailed window and step aggregates from raw evidence when practical.

Calculate the minimum observed request rate and completed-workflow rate across the accepted
steady windows. A minimum is not proof of stability. Describe throughput as stable only when:

- actual concurrency established and maintained the reviewed steady load;
- measured transport, semantic, and workflow correctness is considered;
- throughput shows no material sustained late collapse;
- the generator or shared machine did not become the dominant bottleneck; and
- latency and resource evidence support the wording.

Do not invent a fixed stability percentage before execution. If throughput declines, report
the measured minimum and early-to-late absolute and percentage change without calling it a
stable floor.

One sustained level supports an observed operating point, not “maximum stable RPS.” Reserve
maximum wording for an experiment that actually searches and establishes a boundary.

## Preserve long-duration resources and state

Sample backend, generator, and practical whole-machine resources from pre-traffic baseline
through sustained windows and any reviewed post-load observation. Keep backend working set,
private memory, CPU, threads, and availability distinct from generator resources and
whole-machine CPU, committed memory, and disk context.

Report memory statistics and factual direction over time. Suitable descriptions include
approximately flat, rise then stable, continued rise, or post-load decrease when the samples
support them. Do not diagnose a leak, defect, or capacity ceiling from shape alone.

Record persistent-state behavior. Capture safe pre/post facts such as database size or row
counts when available, without mutating state or removing business operations merely to limit
growth. Interpret resource and latency observations alongside accumulated state.

If post-load recovery is reviewed, start it only after traffic and in-flight work actually
finish. Keep it resource-only unless the design explicitly requires traffic, and do not count
it as sustained-load duration.

## Prepare attributable evidence

Follow [evidence.md](evidence.md). Use sparse screenshots at meaningful early, middle, and
late points rather than high-frequency capture. Each active frame should expose run identity,
window, elapsed time, target and genuine actual concurrency when available, and backend and
generator resources. Mark post-load frames as resource-only.

Preserve raw results even when large. Record byte size and a cryptographic hash; keep required
submission evidence outside Git when repository-size policy requires it. Never delete an
untracked raw result merely because it is large.

Preserve valid bad performance such as latency growth, throughput decline, memory growth,
correctness failure, contention, or threshold failure. Treat implementation mismatch,
identity collision, lost attribution, missing steady concurrency, generator domination,
unexpected restart, or machine instability as invalid or unsafe. Do not rerun automatically.
