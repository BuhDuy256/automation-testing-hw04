# Load Mode

Use Load mode to establish repeatable behavior under a reviewed synthetic normal load. Do not claim that it represents production traffic when no production model exists.

## Evidence inputs

Read hardware facts, SUT architecture, runtime contract, and prior calibration. Establish whether the generator and SUT share a machine because generator load can contaminate SUT observations.

## Calibration

When no trustworthy traffic model exists:

1. Verify the complete workflow at one virtual user for repeated iterations.
2. Separate API processing time, deliberate think-time, and total iteration duration.
3. Explore a small, evidence-derived concurrency progression only after correctness passes.
4. Observe latency distribution, workflow correctness, achieved throughput, backend resources, and generator resources at each level.
5. Stop exploration before it becomes a breaking-point test.
6. Confirm the proposed normal-load level when practical.

Choose the lowest concurrency that produces repeatable overlapping workflows while the SUT and generator remain clearly below visible saturation. Do not select a target merely because it is a common example.

## Scenario design

- Choose a closed or open model from the workflow and available traffic evidence.
- Relate ramps and plateau length to observed iteration completion and desired repeated samples, without presenting convenient durations as statistically mandated.
- Label think-time as a synthetic user-behavior assumption unless analytics support it.
- Keep RPS observational unless a throughput requirement exists.
- Base graceful completion on observed iteration duration and the think-time envelope.

## Thresholds

Use real business SLOs when available. Otherwise derive provisional regression guards from stable low-load measurements and state each chosen tolerance. Keep transport failure, semantic checks, workflow success, API latency, and iteration duration distinct. An iteration metric dominated by think-time is not an API-latency measure.

Load output should establish baseline latency, error, correctness, throughput, and resource behavior for later modes. Human review must accept every synthetic target and tolerance before implementation.
