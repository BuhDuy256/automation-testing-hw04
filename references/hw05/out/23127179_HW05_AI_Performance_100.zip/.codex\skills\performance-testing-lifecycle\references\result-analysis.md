# Result Analysis

Use this flow only when analysis is in scope.

1. Read direct raw results before narrative conclusions.
2. Calculate counts, rates, distributions, per-step samples, and tails from raw data.
3. Compare calculations with the summary and report view; record discrepancies without rewriting originals.
4. Verify workflow/request arithmetic, interruptions, semantic checks, correlations, and thresholds.
5. Align latency, errors, throughput, backend resources, generator resources, and phases by time.
6. Separate **observation**, **interpretation**, and **recommendation**.
7. Identify repeatable degradation, errors, saturation, state growth, and recovery. Do not declare one tail sample a defect without support.
8. Propose thresholds only after inspecting evidence. Separate business SLOs from calibration guards and exploratory boundaries.
9. Classify optimizations:
   - **Feasible:** supported by implementation evidence and applicable.
   - **Unsupported:** plausible but not demonstrated.
   - **Hallucinated:** assumes a nonexistent or contradictory component, bottleneck, or setting.
10. Preserve unfavorable findings and cite raw sources used for corrections.

Do not infer production capacity from one local educational run. State hardware, SUT state, workload model, and evidence limits.
