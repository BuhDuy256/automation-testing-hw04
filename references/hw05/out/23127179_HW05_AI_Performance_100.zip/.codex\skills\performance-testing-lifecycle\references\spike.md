# Spike Mode

Use Spike mode to observe immediate degradation and recovery after an intentional rapid load increase. Preserve the same business workflow and semantic checks.

## Required starting evidence

Read the approved normal-load baseline and any completed Stress evidence. Previous results inform a safe and meaningful spike size but do not automatically determine it.

## Scenario design

Define three visible periods:

1. **Pre-spike:** a stable reference level confirming setup and baseline behavior.
2. **Spike:** a deliberately rapid increase, held only long enough to observe immediate response.
3. **Recovery:** return to the reference level and observe latency, errors, throughput, resources, and workflow correctness.

The rise must be meaningfully faster than Stress progression. If it exposes many gradual intermediate levels, it has become another Stress test.

## Review points

- Justify magnitude from prior evidence, task goals, and safety limits rather than a convenient round number.
- Preserve identity and mutable-state isolation under sudden concurrency.
- Require human review for think-time changes.
- Define recovery observations without inventing a business recovery SLO.
- Retain failures and delayed recovery unless the invocation itself becomes invalid.

Concrete levels, transition speed, holds, recovery duration, and thresholds are task-specific human-reviewed decisions.
